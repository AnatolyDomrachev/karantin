
a = []
n = int(input())
for i in range(n):
    a.append(int(input()))
print(a)
b=0
for i in range(n):
    b = b+a[i]
c = b/n
print(c)