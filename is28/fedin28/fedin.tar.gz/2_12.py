a = []
for i in range(4):
    a.append([])
    for j in range(4):
        a[i].append(int(input()))
print(a)
b=[]
j=int(input())
k=int(input())
b=a[j]
a[j]=a[k]
a[k]=b
print(a)
